from abc import ABC
import logging
import json
import tornado.web
from scripts.config import dab_config, dmn_config
from scripts import service_details, service_list_by_query, services_activation, services_deactivation, \
    service_creation, service_update, service_list
from scripts.utils.json_utils import error_json_formatter


class ServicesController(tornado.web.RequestHandler, ABC):
    def post(self):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            request_body = json.loads(self.request.body)

            for services_available in dmn_config.services_available:
                if services_available['service_name'] == request_body['service_template']:
                    service_xml = services_available['service_xml']
                    break

            if service_xml is None:
                raise AttributeError("Invalid Service Template")

            service_json = {
                "name": request_body['name'],
                "businessLogic": service_creation.handling_decision_keys(service_name=request_body['name'],
                                                                         business_logic=service_xml),
                "expirationDate": request_body['expirationDate'],
                "acceptedPaymentMethods": [
                    {
                        "paymentType": "VDF_TOKEN"
                    }
                ],
            }
            if 'description' in request_body:
                service_json.update({"description": request_body['description']})

            response_code, response_data = \
                service_creation.create_service(request_body=service_json,
                                                dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in ServicesController, Service Creation")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))

    def get(self, service_id=None):
        try:
            _service_id = service_id
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)

            if service_id is not None:
                response_code, response_data = \
                    service_details.get_service_details(service_id=_service_id,
                                                        dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            else:
                current_page = self.get_query_argument("page", default='1')
                current_size = self.get_query_argument("size", default='100')
                response_code, response_data = \
                    service_list.get_service_list(page=current_page, size=current_size,
                                                  dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])

            self.set_status(response_code)
            if response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in ServicesController, Get Service (Details or list)")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))

    def patch(self, service_id):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            request_body = json.loads(self.request.body)
            response_code, response_data = service_update\
                .update(service_id=service_id, request_body=request_body,
                        dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 204:
                self.finish()
            elif response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in ServicesController, Service Creation")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))


class ServicesListController(tornado.web.RequestHandler, ABC):
    def post(self):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            request_body = json.loads(self.request.body)
            response_code, response_data = service_list_by_query\
                .get_service_list_by_query(request_body=request_body,
                                           dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in ServicesListController, Service Query")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))


class ServicesActivationController(tornado.web.RequestHandler, ABC):
    def post(self, service_id):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            response_code, response_data = \
                services_activation.activate(service_id=service_id,
                                             dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 204:
                self.finish()
            elif response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in ServicesActivationController, Service Activation")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))

    def delete(self, service_id):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            response_code, response_data = services_deactivation\
                .deactivate(service_id=service_id, dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 204:
                self.finish()
            elif response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in ServicesActivationController, Service Deactivation")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))


class ServicesTemplateListAvailableController(tornado.web.RequestHandler, ABC):
    def get(self):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            service_template_list = []
            for service_template in dmn_config.services_available:
                service_template_list.append(service_template['service_name'])
            self.set_status(200)
            self.write({'service_templates': service_template_list})
        except Exception as exc:
            logging.error("Exception occurred in ServicesTemplateListAvailableController, Service Template list")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))
