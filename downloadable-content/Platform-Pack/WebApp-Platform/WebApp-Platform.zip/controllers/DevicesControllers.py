from abc import ABC
import logging
import json
import tornado.web

from scripts.config import dab_config
from scripts import device_registration, device_update, device_activation, device_deactivation, \
    device_account_association, device_details, device_list_by_query, device_service_subscription, \
    device_grant_delete, device_grant_update, device_list
from scripts.utils.json_utils import error_json_formatter


class DevicesController(tornado.web.RequestHandler, ABC):
    def post(self):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            response_code, response_data = device_registration.register()
            if response_code == 0:
                try:
                    logging.debug('SDK Response: %s', response_data)
                    response_json = json.loads(response_data[response_data.find('{'):response_data.rfind('}')+1])
                    dab_config.api_credentials['LOCAL-DEVICE-ID'] = response_json['deviceId']
                    dab_config.write_environment_configuration(new_environments=dab_config.api_credentials)
                    response_body = {
                        'details': f"Device Registered. ID: {response_json['deviceId']}"
                    }
                except Exception as e:
                    logging.error("Could not parse the SDk Response: %s", response_data)
                    logging.error("Error on parsing: ", e)
                    response_body = {
                        'details': "Device Registered. But could not received the device ID. "
                                   "Please Verify on the platform."
                    }
                self.set_status(201)
                self.write(response_body)

            else:
                raise EnvironmentError(f"DAB SDK returns an error ({response_code}) on Device Register."
                                       f" {response_data}")
        except Exception as exc:
            logging.error("Exception occurred in DevicesController, Device Register")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))

    def get(self, device_id=None):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            if device_id is not None:
                has_details = self.get_query_argument(name="details", default=True)
                logging.debug('Device ID Received from GUI %s', device_id)
                if device_id == '00000000-0000-0000-0000-000000000000':
                    logging.debug('Replacing Dummy ID from GUI by real Device ID')
                    if 'LOCAL-DEVICE-ID' not in dab_config.api_credentials or \
                            dab_config.api_credentials['LOCAL-DEVICE-ID'] is None or \
                            len(dab_config.api_credentials['LOCAL-DEVICE-ID']) == 0:
                        raise AttributeError("This Device is not registered on DAB. "
                                             "Please, try the Device Register first")
                    device_id = dab_config.api_credentials['LOCAL-DEVICE-ID']

                response_code, response_data = device_details.get_device_details(
                    device_id=device_id, dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'],
                    details=has_details)
            else:
                current_page = self.get_query_argument("page", default='1')
                current_size = self.get_query_argument("size", default='100')
                response_code, response_data = \
                    device_list.get_device_list(page=current_page, size=current_size,
                                                dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in DevicesController, Get Device Details")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))

    def patch(self, device_id):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            request_body = json.loads(self.request.body)
            response_code, response_data = device_update.update(device_id=device_id, request_body=request_body,
                                                                dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 204:
                self.finish()
            elif response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in DevicesController, Device Update")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))


class DevicesQueryController(tornado.web.RequestHandler, ABC):
    def post(self):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            request_body = json.loads(self.request.body)
            if "pageSize" not in request_body:
                request_body.update({"pageSize": 20})
            if "pageNumber" not in request_body:
                request_body.update({"pageNumber": 1})
            response_code, response_data = \
                device_list_by_query.get_device_list_by_query(request_body=request_body,
                                                              dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in DevicesController, Device Query")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))


class DevicesActivationController(tornado.web.RequestHandler, ABC):
    def post(self, device_id):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            response_code, response_data = device_activation.activate(device_id=device_id,
                                                                      dab_account_id=dab_config.api_credentials[
                                                                          'DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 204:
                self.finish()
            elif response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in DevicesController, Device Activation")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))

    def delete(self, device_id):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            response_code, response_data = device_deactivation.deactivate(device_id=device_id,
                                                                          dab_account_id=dab_config.api_credentials[
                                                                              'DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 204:
                self.finish()
            elif response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in DevicesController, Device Deactivation")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))


class DeviceGrantsController(tornado.web.RequestHandler, ABC):
    def post(self):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            request_body = json.loads(self.request.body)

            if 'paymentType' not in request_body:
                request_body.update({"paymentType": "VDF_TOKEN"})

            response_code, response_data = \
                device_service_subscription.service_subscription(request_body=request_body,
                                                                 dab_account_id=dab_config.api_credentials[
                                                                     'DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if 200 < response_code < 400 and len(response_data) == 0:
                self.write({})
            elif response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in DeviceGrantsController, Device Service Subscription")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))

    def patch(self, device_id, grant_id):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            request_body = json.loads(self.request.body)
            response_code, response_data = device_grant_update\
                .update_grant(device_id=device_id, grant_id=grant_id, request_body=request_body,
                              dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 204:
                self.finish()
            elif response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in DeviceGrantsController, Device Grant Update")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))

    def delete(self, device_id, grant_id):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            response_code, response_data = device_grant_delete\
                .delete_grant(device_id=device_id, grant_id=grant_id,
                              dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 204:
                self.finish()
            elif response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in DeviceGrantsController, Device Grant Delete")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))


class DeviceAssignmentController(tornado.web.RequestHandler, ABC):
    def post(self, device_id):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            response_code, response_data = \
                device_account_association\
                    .assign_to_dab_account(device_id=device_id,
                                           dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in DeviceAssignmentController, Device Assignment")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))
