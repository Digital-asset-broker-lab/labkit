from base64 import b64encode
from json.decoder import JSONDecodeError
import requests
import logging
import sys


def get_credential(credentials, scope):
    if 'user' in credentials and 'passwd' in credentials:
        user = credentials['user']
        passwd = credentials['passwd']
    else:
        if scope in credentials:
            user = credentials[scope][0]
            passwd = credentials[scope][1]
        else:
            logging.fatal("Credential %s not found", scope)
            sys.exit(1)
    user_and_pass = b64encode(bytes(f"{user}:{passwd}", "UTF-8")).decode("ascii")
    return user_and_pass


def get_headers(credentials, scope, environment, sending_json, additional_headers, dab_account_id=None):
    headers = {
        'Accept': 'application/json',
        'vf-target-environment': environment['name']
    }
    if scope in credentials:
        cred = credentials[scope]
        if cred['mode'] == 'basic':
            client_id = cred['client-id']
            client_secret = cred['client-secret']
            encoded = b64encode(bytes(f"{client_id}:{client_secret}", "UTF-8")).decode("ascii")
            headers['Authorization'] = f'Basic {encoded}'
            if "apix-client-id" in cred:
                headers['vf-apix-app-id'] = cred['apix-client-id']

        else:
            token = cred['access-token']
            headers['Authorization'] = f'Bearer {token}'

        if dab_account_id is not None:
            headers['dab-account-id'] = dab_account_id
            headers['x-jws-signature'] = dab_account_id

        if additional_headers is not None:
            headers.update(additional_headers)
        if sending_json:
            headers['Content-Type'] = 'application/json'
    else:
        logging.fatal("Fatal error - scope %s not found in credentials", scope)
        sys.exit(1)
    return headers


def has_json(resp):
    json_data = False
    if resp.content is not None:
        if len(resp.content) > 0:
            json_data = 'Content-Type' in resp.headers and resp.headers['Content-Type'].startswith('application/json')
    return json_data


def print_response(resp):
    if resp.status_code >= 400:
        logging.warning('Error %s %s', resp.status_code, resp.content)
    logging.debug('Status code: %s', resp.status_code)
    for k, v in resp.headers.items():
        logging.debug('Response header %s: %s', k, v)
    if has_json(resp):
        try:
            logging.debug('JSON data is: %s', resp.json())
        except JSONDecodeError as exc:
            logging.error("Error Details: %s", exc)
            logging.debug("Raw Data received: %s", resp)
            return


def send_request(_method, _url, _credentials, _scope, _environment, _json_data=None,
                 _additional_headers=None, _dab_account_id=None):
    sending_json = _json_data is not None
    logging.debug('Making %s request to %s', _method, _url)
    if sending_json:
        logging.debug("Request JSON data: %s", _json_data)
    _headers = get_headers(_credentials, _scope, _environment, sending_json=sending_json,
                           additional_headers=_additional_headers, dab_account_id=_dab_account_id)
    if logging.DEBUG >= logging.root.level:
        for k, v in _headers.items():
            if k == 'Authorization':
                logging.debug('Request header Authorization: Omitted')
            else:
                logging.debug('Request header %s: %s', k, v)

    resp = requests.request(method=_method, url=_url, headers=_headers, json=_json_data)
    print_response(resp)

    return resp


def send_form_request(_method, _url, _credentials, _scope, _environment, _form_data=None,
                      _additional_headers=None, _dab_account_id=None):
    sending_data = _form_data is not None
    logging.debug('Making %s request to %s', _method, _url)
    if sending_data:
        logging.debug("Request data: %s", _form_data)

    if _additional_headers is None:
        _additional_headers = {}
    _additional_headers.update({"Content-Type": "application/x-www-form-urlencoded"})
    headers = get_headers(_credentials, _scope, _environment, additional_headers=_additional_headers,
                          dab_account_id=_dab_account_id, sending_json=None)

    if logging.DEBUG >= logging.root.level:
        for k, v in headers.items():
            if k == 'Authorization':
                logging.debug('Request header Authorization: Omitted')
            else:
                logging.debug('Request header %s: %s', k, v)

    resp = requests.request(method=_method, url=_url, headers=headers, data=_form_data)
    print_response(resp)

    return resp


def default_response_handling(resp):
    code = resp.status_code
    try:
        if 200 <= code < 400:
            if has_json(resp):
                data = resp.json()
            else:
                data = ""
        elif 400 <= code < 500 and has_json(resp):
            data = resp.json()
            logging.error("DAB returns a client error (%s), JSON message: %s", code, data)
        elif code > 500 and has_json(resp):
            data = resp.json()
            logging.error("DAB returns a Server error (%s), JSON message: %s", code, data)
        elif code >= 400:
            data = resp.content
            logging.error("DAB Servers returns a Unmapped error returned (%s), RAW message: %s", code, data)
        else:
            logging.error("Unknown Error...")
            data = 'Unknown Error...'
        return code, data
    except JSONDecodeError as exc:
        data = "Invalid response returned from DAB"
        logging.error("Error Details: %s", exc)
        logging.debug(data)
        return code, data
