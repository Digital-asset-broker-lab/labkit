import json
import logging
import sys

defaultNodes = {
    'BT3-DEMO': 'OU=DAB BT3-Demo Node 1, O="O=Fifth-9 Limited UK", L=London, ST=London, C=GB',
}

nodeSet = {
    'BT3-DEMO': {
        'Node1': 'OU=DAB BT3-Demo Node 1, O="O=Fifth-9 Limited UK", L=London, ST=London, C=GB',
        'Node2': 'OU=DAB BT3-Demo Node 2, O="O=Fifth-9 Limited UK", L=London, ST=London, C=GB',
    },
}

directUrlBase = {
    'BT3-DEMO': {
        'auth': 'authdm.digital-asset-broker.com',
        'prov': 'provdm.digital-asset-broker.com',
        'tx': 'txdm.digital-asset-broker.com',
    }
}

environments = {}
services = {}
api_credentials = {}


def load_environment_configuration(required_env='BT3-DEMO', api_credentials_json='api_credentials.json'):
    try:
        logging.debug('Loading Config file: %s', api_credentials_json)
        with open(api_credentials_json) as fp:
            dab_api_credentials = json.load(fp)
    except EOFError as e:
        logging.fatal('Failed on load api_credentials file. File not found or accessible: %s', api_credentials_json)
        exit(1)

    if len(dab_api_credentials.keys()) == 0:
        logging.fatal(f'No credentials available')
        sys.exit(0)

    dab_environments = {
        'name': required_env,
        'defaultNode': defaultNodes[required_env],
    }

    domain = directUrlBase[required_env]
    auth_domain = domain['auth']
    prov_domain = domain['prov']
    tx_domain = domain['tx']

    dab_microservice = {
        'auth': f'https://{auth_domain}/dab-service/auth',
        'tx': f'https://{tx_domain}/dab-service/trans',
        'prov': f'https://{prov_domain}/dab-service/prov'
    }

    dab_environments['services'] = dab_microservice
    dab_environments['api_credentials'] = dab_api_credentials

    services.update(dab_microservice)
    environments.update(dab_environments)
    api_credentials.update(dab_api_credentials)


def write_environment_configuration(required_env='BT3-DEMO', api_credentials_json='api_credentials.json',
                                    new_environments=None):
    try:
        if new_environments is None:
            new_environments = environments['api_credentials']
        # Serializing json
        json_object = json.dumps(new_environments, indent=4)

        # Writing to config file
        with open(api_credentials_json, "w") as outfile:
            outfile.write(json_object)
    except EOFError as e:
        logging.fatal('Failed on write updated api_credentials file. File not found or accessible: %s',
                      api_credentials_json)
