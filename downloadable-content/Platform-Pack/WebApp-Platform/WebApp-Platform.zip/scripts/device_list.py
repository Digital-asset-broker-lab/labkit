import argparse
import logging
import scripts_paths_adapter
from scripts.config import dab_config
from scripts.utils.request_utils import send_request, default_response_handling


def get_device_list(dab_account_id, page=1, size=100):

    logging.debug('Retrieving Device list')
    extra_headers = {}

    url = dab_config.services['auth'] + f"/devices?page={page}&size={size}"

    resp = send_request(_method='GET', _url=url, _credentials=dab_config.api_credentials, _scope="BT3-DEMO-OAUTH",
                        _environment=dab_config.environments, _dab_account_id=dab_account_id,
                        _additional_headers=extra_headers)
    return default_response_handling(resp)


def setup_args():
    parser = argparse.ArgumentParser(description="DAB Services - Get Device List Script",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("-e", "--env", help="DAB environment", default='BT3-DEMO', nargs='?')
    parser.add_argument("-c", "--credentials", help="API Credentials file", default='api_credentials.json', nargs='?')
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable Debug logging")
    parser.add_argument("-a", "--account", help="DAB Account ID", nargs='?')
    parser.add_argument("--page", help="DAB environment", type=int, default=1, nargs='?')
    parser.add_argument("--size", help="DAB environment", type=int, default=20, nargs='?')
    args = parser.parse_args()
    return vars(args)


if __name__ == '__main__':
    scripts_paths_adapter.dummy()
    config = setup_args()

    if config is None:

        logging.error('Configuration not found. Script cannot be executed.')
        exit(1)

    else:

        dab_config.load_environment_configuration(config['env'], config['credentials'])
        debugMode = config['verbose']
        if debugMode:
            logging.root.setLevel(logging.DEBUG)

        try:

            dab_account = None
            if config['account'] is not None:
                dab_account = config['account']
            else:
                dab_account = dab_config.api_credentials['DAB-ACCOUNT-ID']

            current_page = config['page']
            page_size = config['size']
            response_code, response_data = get_device_list(dab_account_id=dab_account, page=current_page,
                                                           size=page_size)

            if response_code >= 400:
                logging.error('Get Device List returns an error code: %s. Response content: %s',
                              response_code, response_data)
                print(response_data)
                exit(response_code)
            else:
                print(response_data)

        except Exception as e:
            logging.error('Get Device List could not be processed', e)
            exit(1)

    exit(0)
