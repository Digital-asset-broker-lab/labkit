import argparse
import logging
import scripts_paths_adapter
import json
from xml.dom import minidom
from scripts.config import dab_config, dmn_config
from scripts.utils.request_utils import send_request, default_response_handling


def create_service(request_body, dab_account_id):

    logging.debug('Creating Service.')
    logging.debug('Request Body: %s', request_body)
    extra_headers = {}
    if dab_account_id is not None and len(dab_account_id) > 0:
        extra_headers = {
            "x-jws-signature": dab_account_id
        }
    url = dab_config.services['prov'] + f"/services"

    resp = send_request(_method='POST', _url=url, _credentials=dab_config.api_credentials, _scope="BT3-DEMO-OAUTH",
                        _environment=dab_config.environments, _dab_account_id=dab_account_id,
                        _additional_headers=extra_headers, _json_data=request_body)

    return default_response_handling(resp)


def handling_decision_keys(service_name, business_logic):
    parsed = minidom.parseString(business_logic)
    collection = parsed.documentElement
    decisions = collection.getElementsByTagName("decision")
    for decision_tag in decisions:
        decision_tag.setAttribute('id', f'{service_name.replace(" ", "_")}')
        decision_tag.setAttribute('name', f'{service_name.replace(" ", "_")}')
    return parsed.toxml()


def setup_args():
    json_example = {
        "name": "Parking Service",
        "expirationDate": "2031-12-10T11:04:33.842",
        "acceptedPaymentMethods": [
          {
            "paymentMethod": "VISA_TOKEN"
          }
        ],
        "description": "string"
    }

    parser = argparse.ArgumentParser(description="DAB Services - Service Creation Script",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter, exit_on_error=False)
    parser.add_argument('-e', '--env', help='DAB environment', default='BT3-DEMO', nargs='?')
    parser.add_argument("-c", "--credentials", help="API Credentials file", default='api_credentials.json', nargs='?')
    parser.add_argument('-v', '--verbose', action='store_true', help='Enable Debug logging')
    service_template_list = []
    for service_template in dmn_config.services_available:
        service_template_list.append(service_template['service_name'])
    parser.add_argument("-t", "--template", help="Service template name", choices=service_template_list, required=True)
    parser.add_argument('-j', '--json', help=f'Json. E.g.: {json_example}', default='{}',  nargs='?')
    parser.add_argument('-a', '--account', help='DAB Account ID', nargs='?')
    args = parser.parse_args()
    return vars(args)


if __name__ == '__main__':
    scripts_paths_adapter.dummy()
    dmn_config.load_dmn_files()
    config = setup_args()

    if config is None:

        logging.error('Configuration not found. Script cannot be executed.')
        exit(1)

    else:

        dab_config.load_environment_configuration(config['env'], config['credentials']),
        debugMode = config['verbose']
        if debugMode:
            logging.root.setLevel(logging.DEBUG)

        try:

            dab_account = None
            if config['account'] is not None:
                dab_account = config['account']
            else:
                dab_account = dab_config.api_credentials['DAB-ACCOUNT-ID']

            received_json = json.loads(config['json'])
            template_name = config['template']

            for services_available in dmn_config.services_available:
                if services_available['service_name'] == template_name:
                    service_xml = services_available['service_xml']
                    break

            if service_xml is None:
                raise AttributeError("Invalid Service Template")

            service_json = {
                "name": received_json['name'],
                "businessLogic": handling_decision_keys(service_name= received_json['name'],
                                                        business_logic=service_xml),
                "expirationDate": received_json['expirationDate'],
                "acceptedPaymentMethods": received_json['acceptedPaymentMethods'],
                "description": received_json['description']
            }

            response_code, response_data = create_service(request_body=service_json, dab_account_id=dab_account)

            if response_code >= 400:
                logging.error('Service Creation returns an error code: %s. Response content: %s',
                              response_code, response_data)
                print(response_data)
                exit(response_code)
            else:
                print(response_data)

        except Exception as e:
            logging.error('Service Creation could not be processed', e)
            exit(1)

    exit(0)
