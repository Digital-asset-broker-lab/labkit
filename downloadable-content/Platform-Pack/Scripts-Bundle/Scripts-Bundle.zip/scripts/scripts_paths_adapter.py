import logging
from pathlib import Path as Path_utils
from sys import path as sys_path
sys_path.append(f'{Path_utils(__file__).parent.parent}')


def dummy():
    logging.debug(f"Including {f'{Path_utils(__file__).parent.parent}'} on Python Path to use same scripts/imports "
                  f"ignoring hierarchy when starts from a Script")
