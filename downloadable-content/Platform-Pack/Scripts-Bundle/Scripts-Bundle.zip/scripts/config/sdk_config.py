import logging

sdk = {
    'DAB_APP_WRAPPER_PATH': '/opt/dab-sdk/dab-app-wrapper',
    'CONFIG_INI_PATH': '/opt/dab-sdk/config.ini',
}


def load_sdk_configuration():
    pass


def update_sdk_configuration(client_id):
    replaced_content = ""
    try:
        with open(sdk['CONFIG_INI_PATH'], "r") as infile:
            for line in infile:
                line = line.strip()
                if "dab.target.vf-apix-app-id" in line:
                    line = f'dab.target.vf-apix-app-id = {client_id}'
                replaced_content = replaced_content + line + "\n"
    except EOFError as e:
        logging.critical('Failed on Read SDK Config ini file. File not found or accessible: %s',
                         sdk['CONFIG_INI_PATH'])
        raise e

    try:
        with open(sdk['CONFIG_INI_PATH'], "w") as outfile:
            outfile.write(replaced_content)
    except EOFError as e:
        logging.critical('Failed on update SDK Config ini file. File not found or accessible: %s',
                         sdk['CONFIG_INI_PATH'])
        raise e
