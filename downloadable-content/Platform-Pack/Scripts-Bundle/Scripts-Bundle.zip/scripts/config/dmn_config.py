import logging

xml_files = [
    {
        'service_name': 'My ID Service',
        'file': 'dmn_samples/deviceidservice.xml',
        'engine': 'DMN'
    },
    {
        'service_name': 'Eletric Charger',
        'file': 'dmn_samples/electricCharged.xml',
        'engine': 'DMN'
    },
    {
        'service_name': 'Hello World',
        'file': 'dmn_samples/helloWorld.xml',
        'engine': 'DMN'
    },
    {
        'service_name': 'Parking Service',
        'file': 'dmn_samples/parkingservice.xml',
        'engine': 'DMN'
    },
    {
        'service_name': 'Smart meter',
        'file': 'dmn_samples/smart_meter.xml',
        'engine': 'DMN'
    },
    {
        'service_name': 'Temperature Comparator',
        'file': 'dmn_samples/temperatureComparator.xml',
        'engine': 'DMN'
    },
    {
        'service_name': 'Theme Park',
        'file': 'dmn_samples/themePark.xml',
        'engine': 'DMN'
    },
]

services_available = []


def load_dmn_files(base_path=''):
    for xml_file in xml_files:
        dmn_code = None
        try:
            logging.debug('Expecting DMN code in %s', xml_file['file'])
            with open(base_path+xml_file['file']) as fp:
                dmn_code = fp.read()
        except IOError as exc:
            logging.debug("File not found %s ", xml_file['file'], exc)
            logging.error("File not found %s ", xml_file['file'])

        services_available.append({
            'service_name': xml_file['service_name'],
            'service_xml': dmn_code,
            'engine': xml_file['engine']
        })
