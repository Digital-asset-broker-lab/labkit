import argparse
import logging
import subprocess
import shlex
import scripts_paths_adapter
from scripts.config import dab_config, sdk_config
from scripts.utils import json_utils


def register():

    dab_app_wrapper = sdk_config.sdk['DAB_APP_WRAPPER_PATH']
    config_ini = sdk_config.sdk['CONFIG_INI_PATH']

    try:
        completed_process = subprocess.run(shlex.split(f'{dab_app_wrapper} -c {config_ini} -r'),
                                           capture_output=True, text=True)

        return_data = completed_process.stdout

        if completed_process.returncode != 0:
            logging.warning('Process failed because did not return a successful return code: %s',
                            completed_process.returncode)
            return_data = completed_process.stderr

        return completed_process.returncode, return_data

    except FileNotFoundError as exc:
        logging.fatal('Process failed because the executable could not be found.\n %s')
        raise exc

    except subprocess.SubprocessError as exc:
        logging.warning('Error on execute subprocess call: %s', exc)
        raise exc


def setup_args():

    parser = argparse.ArgumentParser(description="DAB SDK - Device Registration Script",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument("-e", "--env", help="DAB environment", default='BT3-DEMO', nargs='?')
    parser.add_argument("-c", "--credentials", help="API Credentials file", default='api_credentials.json', nargs='?')
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable Debug logging")

    args = parser.parse_args()

    return vars(args)


if __name__ == '__main__':
    scripts_paths_adapter.dummy()
    config = setup_args()

    if config is None:

        logging.error('Configuration not found. Script cannot be executed.')
        exit(1)

    else:

        dab_config.load_environment_configuration(config['env'], config['credentials']),
        sdk_config.load_sdk_configuration()
        debugMode = config['verbose']

        if debugMode:
            logging.root.setLevel(logging.DEBUG)

        try:
            response_code, response_data = register()
            if response_code != 0:
                logging.warning("DAB SDK returned an error when Registering a device: %s", response_data)

            json_content = json_utils.extract_json_from_string(response_data)
            if json_content:
                for json in json_content:
                    print(json)
            else:
                print(response_data)
            exit(response_code)

        except Exception as e:
            logging.error('Device Registration Script could not be processed', e)
            exit(1)
