import argparse
import logging
import scripts_paths_adapter
from scripts.config import dab_config
from scripts.utils.request_utils import send_request, default_response_handling


def assign_to_dab_account(device_id, dab_account_id):

    logging.debug('Assigning Device to a DAB Account. Device ID: %s', device_id)
    extra_headers = {}
    if dab_account_id is not None and len(dab_account_id) > 0:
        extra_headers = {
            "x-jws-signature": dab_account_id
        }
    url = dab_config.services['auth'] + f"/devices/assignment"

    resp = send_request(_method='POST', _url=url, _credentials=dab_config.api_credentials, _scope="BT3-DEMO-OAUTH",
                        _environment=dab_config.environments, _dab_account_id=dab_account_id,
                        _additional_headers=extra_headers, _json_data=device_id)

    return default_response_handling(resp)


def setup_args():
    parser = argparse.ArgumentParser(description="DAB Services - Get Device List by query Script",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter, exit_on_error=False)
    parser.add_argument('-e', '--env', help='DAB environment', default='BT3-DEMO', nargs='?')
    parser.add_argument("-c", "--credentials", help="API Credentials file", default='api_credentials.json', nargs='?')
    parser.add_argument('-v', '--verbose', action='store_true', help='Enable Debug logging')
    parser.add_argument("-d", "--device", help="Device ID", nargs='?')
    parser.add_argument('-a', '--account', help='DAB Account ID', nargs='?')
    args = parser.parse_args()
    return vars(args)


if __name__ == '__main__':
    scripts_paths_adapter.dummy()
    config = setup_args()

    if config is None:

        logging.error('Configuration not found. Script cannot be executed.')
        exit(1)

    else:

        dab_config.load_environment_configuration(config['env'], config['credentials']),
        debugMode = config['verbose']
        if debugMode:
            logging.root.setLevel(logging.DEBUG)

        try:

            device = config['device']
            dab_account = None
            if config['account'] is not None:
                dab_account = config['account']
            else:
                dab_account = dab_config.api_credentials['DAB-ACCOUNT-ID']

            response_code, response_data = assign_to_dab_account(device_id=device, dab_account_id=dab_account)

            if response_code >= 400:
                logging.error('Get Device List By Query returns an error code: %s. Response content: %s',
                              response_code, response_data)
                print(response_data)
                exit(response_code)
            else:
                print(response_data)

        except Exception as e:
            logging.error('Get Device List By Query could not be processed', e)
            exit(1)

    exit(0)
