#!/bin/bash
apt update -y && sudo apt upgrade -y
apt install python3 python3-pip pipenv -y
pip install regex 
pip install requests
