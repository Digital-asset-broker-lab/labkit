#!/bin/bash

FILE=$1

if [ -f "$FILE" ]; then
    echo ""
    echo "DAB-SDK extractor helper"
    echo "=========================="
    echo "The default installation will install whole dab-sdk with default parameters."

    # Default installation
    SKIP_CONFIRMATION=true

    echo ""
    if ! $SKIP_CONFIRMATION; then 
        read -p "Select your target folder [/opt/dab-sdk]: " TARGET_PATH 
    fi

    TARGET_PATH=${TARGET_PATH:-"/opt/dab-sdk"}

    # "Deleting current $TARGET_PATH..."
    sudo rm -R $TARGET_PATH

    tar -xvf $1
    sudo mv ./dab-sdk $TARGET_PATH
    sudo chmod -R 744 $TARGET_PATH/*.sh
	sudo chmod -R 744 $TARGET_PATH/*.sh.default
    sudo chown -R $USER:$USER $TARGET_PATH/
    echo "DAB-SDK extracted on $TARGET_PATH. You can start the setup using the setup.sh on dab-sdk folder."

    # Generating a default config.ini
    echo "Generating a default config.ini..."
    sudo rm $TARGET_PATH/config.ini
    echo "
;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;
;;                    ;;
;; Config.ini Options ;;
;;                    ;;
;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;

;; Section: DAB_SERVICE ;;
;; This section contains the parameters related to DAB Platform integration;;
[DAB_SERVICE]

;; Target DAB Environment on APIX (Mandatory)
;; DAB-SDK as configured to connect to DAB Platform via APIX as default. 
;; You must to select the target environment in order to inform APIX to which environment redirect the SDK request.
;;	Values: [BT3-PRIME-DEV, BT3-PRIME-DEV2, BT3-PRIME-LIT, BT3-PRIME-DEMO, BT3-PRIME-QA, BT3-PRIME-QA2]
dab.service.target.environment = BT3-PRIME-DEMO

;; URL to DAB Microservice Authentication
;; DAB-SDK as configured to connect to DAB Platform via APIX as default. 
;; If need to change the configuration to a specific DAB instance, you can device the URL+ENDPOINT to DAB Authentication uncommenting the line below: 
dab.service.url.auth = https://authdm.digital-asset-broker.com/dab-service/auth

;; URL to DAB Microservice Transactions
;; DAB-SDK as configured to connect to DAB Platform via APIX as default. 
;; If need to change the configuration to a specific DAB instance, you can device the URL+ENDPOINT to DAB Transactions uncommenting the line below: 
dab.service.url.transaction = https://txdm.digital-asset-broker.com/dab-service/trans

;; APIX headers temporally to unblock BT3-PRIME communication. TO BE REMOVED (Development only)
;; Allow to include new headers to provide BT3-PRIME support while APIX it's not available.
dab.target.vf-apix-app-id = <apix_id>

;; ===================================================================================================================================================;;
;; Section: DAB_SIM_WRAPPER ;;
;; This section contains the parameters related to SIMCARD integration ;;
[DAB_SIM_WRAPPER]

;; Modem's Port to SIM Commands
;; DAB-SDK tries to identify the connected modem and ports related. If not found, DAB-SDK is configured to use /dev/ttyUSB2 as default.
;; However, you can specify the correct port if you have more than one devices connected. 
;dab.sim.modem.port = /dev/ttyUSB2

;; ===================================================================================================================================================;;
;; Section: DAB_SIM_TRUST ;;
;; This section contains the parameters related to DAB_SIM_TRUST module;;
;; EXCLUSIVE - Used only if the signing method selected above is SIM_TRUST
[DAB_SIM_TRUST]

;; SIM_TRUST Server Addr
;; Used to define the server address for the connection.
;; If disabled, a hardcoded address (http://100.71.0.6:80) will be used.
;dab.simtrust.server.addr = http://lb.dab-co.uk:80

;; SIM_TRUST User Agent
;; Used to define an user agent for the connection with the server.
;; If disabled, a hardcoded address will be used.
;dab.simtrust.user.agent = 3gpp-gba-tmpi

;; ===================================================================================================================================================;;
;; Section: DAB_DATA ;;
;; This section contains the parameters related to local data storage;;
[DAB_DATA]

;; Encrypted config file
;; Some configurations can contains sensitive information and are stored into a encrypted file instead this config.ini
;; Configure the path to the encrypted config file
;; If this file don't exists, it's will be created dynamically when some sensitive parameter needs to be stored. E.g.: APIX/DAB Credentials. 
dab.store.enc.conf = /opt/dab-sdk/dab-sdk-enc-conf.dat

;; Encrypted data file
;; Some data stored can contains sensitive information and are stored into a encrypted file.
;; Configure the path to the encrypted data file
;; If this file don't exists, it's will be created dynamically when some sensitive data needs to be stored.
dab.store.enc.data = /opt/dab-sdk/dab-sdk-enc-data.dat

;; ===================================================================================================================================================;;
;; Section: DAB_APP_WRAPPER ;;
;; This section contains the parameters related to DAB_APP_WRAPPER application;;
;; Used inclusive by other applications (E.g.: DAB-SMS-HANDLER) to find dab-app-wrapper's path;;
[DAB_APP_WRAPPER]

;; Dab-app-wrapper's path
;; The absolute Path to dab-mw-sdk executable
dab.app.wrapper.path = /opt/dab-sdk/dab-app-wrapper

;; Dab-app-wrapper's Logs output file
;; The absolute Path to dab-sdk's logs output file
;; The log level reflects directly to generated log size. Be careful.
;; If no output file is specified, the outputs will be printed on the console.
dab.app.wrapper.log.outputfile = /opt/dab-sdk/dab-app-wrapper.log

;; Dab-app-wrapper's Log level
;; As default, DAB-SDK has a log level WARN (Warning). 
;; The log level reflects directly to generated log size. Be careful.
;; Values: [NONE, FATAL, ERROR, WARN, INFO, DEBUG]
dab.app.wrapper.log.level = WARN

;; ===================================================================================================================================================;;
;; Section: DAB_SMS_HANDLER ;;
;; This section contains the parameters related to DAB_SMS_HANDLER application;;
[DAB_SMS_HANDLER]

;; Dab-sms-handler's Logs output file
;; The absolute Path to dab-sms-handler's logs output file
;; If no output file is specified, the outputs will be printed on the console.
dab.sms.log.outputfile = /opt/dab-sdk/dab-sms-handler.log

;; Dab-sms-handler's Log level
;; As default, DAB-SDK has a log level WARN (Warning). 
;; The log level reflects directly to generated log size. Be careful.
;; Values: [NONE, FATAL, ERROR, WARN, INFO, DEBUG]
dab.sms.log.level = WARN

;; Configuration file to be used by sms handler
;; Referes to config.ini (like this) to be used by dab-sms-handler to interact with dab-app-wrapper.
;; The absolute Path to config.ini
dab.sms.configfile = /opt/dab-sdk/config.ini

" >> $TARGET_PATH/config.ini
    echo "Done."

    #--------------------------------------------------------------------
    # Setting dab.target.vf-apix-app-id
	#--------------------------------------------------------------------
    read -p "Enter the APIX Client ID (dab.target.vf-apix-id):" APIX_ID
	if [ -z "$APIX_ID" ]
	then
        $APIX_ID = dab-device
	fi

    $(sudo sed -i "s#<apix_id>#$APIX_ID#g" $TARGET_PATH/config.ini);
	#--------------------------------------------------------------------

    # Preparing startup script
    sleep 2;
    mv $TARGET_PATH/startup.sh.default $TARGET_PATH/startup.sh;
    sleep 2;
    $(sudo sed -i "s#<target_path>#$TARGET_PATH#g" $TARGET_PATH/startup.sh);
	$(sudo sed -i "s#<current_user>#$USER#g" $TARGET_PATH/startup.sh);

    # Running setup script		
    cd $TARGET_PATH

    #=============================================================================
    #bash ./setup.sh SKIP_CONFIRMATION
	#=============================================================================
    # Startup script controls
    SetStartup()
    {
        # Preparing rc.local (removing old script calls and comments conflicts)
        CURRENT_MODEM_EXPRESSION_1=$(grep -n "that the script will" /etc/rc.local | cut -f1 -d:)

        if ! [[ -z "$CURRENT_MODEM_EXPRESSION_1" ]]
        then
            $(sudo sed -i "${CURRENT_MODEM_EXPRESSION_1}d" /etc/rc.local);
        fi

		CURRENT_MODEM_EXPRESSION_2=$(grep -n "value on error" /etc/rc.local | cut -f1 -d:)

		if ! [[ -z "$CURRENT_MODEM_EXPRESSION_2" ]]
		then
			$(sudo sed -i "${CURRENT_MODEM_EXPRESSION_2}d" /etc/rc.local);
		fi

		# Removing old scripts
		CURRENT_MODEM_EXPRESSION_3=$(grep -n "iotsafe-dongle-start.sh" /etc/rc.local | cut -f1 -d:)
		if ! [[ -z "$CURRENT_MODEM_EXPRESSION_3" ]]
		then
			$(sudo sed -i "${CURRENT_MODEM_EXPRESSION_3}d" /etc/rc.local);
		fi

		CURRENT_MODEM_EXPRESSION_4=$(grep -n "usbConnect-dongle-start.sh" /etc/rc.local | cut -f1 -d:)
		if ! [[ -z "$CURRENT_MODEM_EXPRESSION_4" ]]
		then
			$(sudo sed -i "${CURRENT_MODEM_EXPRESSION_4}d" /etc/rc.local);
		fi

		# Removing current script
		CURRENT_MODEM_EXPRESSION_5=$(grep -n "startup.sh" /etc/rc.local | cut -f1 -d:)

		if ! [[ -z "$CURRENT_MODEM_EXPRESSION_5" ]]
		then
			$(sudo sed -i "${CURRENT_MODEM_EXPRESSION_5}{N;d;}" /etc/rc.local);
		fi

		# Adding a new startup script call in the end of the file (before exit 0)
		EXIT_EXPRESSION="exit 0"
		MODEM_EXPRESSION="bash $MODEM_STARTUP_SCRIPT"

		$(sudo sed -i "s#$EXIT_EXPRESSION#sleep 30 \&\& $MODEM_EXPRESSION \&\n\nexit 0#g" /etc/rc.local);

		echo "Modem startup process has added on /etc/rc.local.";

		# Wizard mode and confirmation controls
		if ! $SKIP_CONFIRMATION; then
			echo ""
			read -p $'Do you want to start the dongle connection now?[Y/n]' -n 1 -r
		fi

		echo ""
		if [[ $REPLY =~ ^[Yy]$ ]] || $SKIP_CONFIRMATION
		then
			if ! $SKIP_CONFIRMATION; then
				bash $MODEM_STARTUP_SCRIPT NEEDS_CONFIRMATION
			else
				bash $MODEM_STARTUP_SCRIPT
			fi
		fi
	}

	MODEM_STARTUP_SCRIPT=$(pwd)/startup.sh

	# SDK Libraries
	LIB_PATH=$(pwd)/lib

	echo "Installing dab-sdk libs..."

	if [[ -d "/etc/ld.so.conf.d/" ]];
	then
		echo "Creating the dab-sdk.conf in /etc/ld.so.conf.d/..."
		echo $LIB_PATH > ./dab-sdk.conf
		sudo mv ./dab-sdk.conf /etc/ld.so.conf.d/dab-sdk.conf
	else
		echo "Adding  to /etc/ld.so.conf..."
		echo $LIB_PATH | sudo tee -a /etc/ld.so.conf
	fi

	echo "Reloading LD cache..."
	echo $(sudo ldconfig -v | grep "dab")
	echo "DBA SDK libs installed..."

	# Setting config.ini file
	echo "Updating config.ini with current path"

	CURRENT_PATH=$(pwd)

	sed -i 's|.*dab\.store\.enc\.conf.*|dab\.store\.enc\.conf = '"$CURRENT_PATH"'\/dab-sdk-enc-conf.dat ; |g' ./config.ini
	sed -i 's|.*dab\.store\.enc\.data.*|dab\.store\.enc\.data = '"$CURRENT_PATH"'\/dab-sdk-enc-data.dat ; |g' ./config.ini
	sed -i 's|.*dab\.app\.wrapper\.path.*|dab\.app\.wrapper\.path = '"$CURRENT_PATH"'\/dab-app-wrapper |g' ./config.ini
	sed -i 's|.*dab\.app\.wrapper\.log.outputfile.*|dab\.app\.wrapper\.log\.outputfile = '"$CURRENT_PATH"'\/dab-app-wrapper\.log |g' ./config.ini
	sed -i 's|.*dab\.sms\.log\.outputfile.*|dab\.sms\.log\.outputfile = '"$CURRENT_PATH"'\/dab-sms-handler\.log |g' ./config.ini
	sed -i 's|.*dab\.sms\.configfile.*|dab\.sms\.configfile = '"$CURRENT_PATH"'\/config\.ini |g' ./config.ini

	sudo apt update -y
	sudo apt install build-essential doxygen snapd libssl-dev make gcc g++ zlib1g-dev git -y
	sudo snap install --candidate cmake --classic

	# Setting DAB Credentials
	echo "Setting DAB Credentials..."
	./dab-app-wrapper --set-client-id "${APIX_ID}" --set-client-secret "${APIX_ID}"
    echo "Done."

	# Setting modem connection
	echo ""
	echo "IoTSafe Dongle connection will be configure..."
	bash ./setup-modem.sh -s true

	# Setting startup 
	SetStartup

	# SMS Handler process
	echo ""
	bash ./dab-sms-handler-scheduler.sh SKIP_CONFIRMATION
	#=============================================================================
fi
