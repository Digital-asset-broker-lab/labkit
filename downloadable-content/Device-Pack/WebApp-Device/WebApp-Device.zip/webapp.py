from abc import ABC
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from tornado.options import define, options
from tornado.web import Application, RequestHandler
import argparse
import json
import logging
import os
import webapp_paths_adapter
from controllers import ErrorHandlingUtils
from controllers.DevicesControllers import DevicesController, DevicesActivationController, \
    DevicesQueryController, DeviceGrantsController, DeviceAssignmentController
from controllers.ServicesControllers import ServicesController, ServicesListController, \
    ServicesActivationController, ServicesTemplateListAvailableController
from controllers.TransactionsControllers import TriggerTransactionsController, TransactionsController
from scripts.config import dab_config, sdk_config, dmn_config
from scripts.utils.json_utils import error_json_formatter

config_file_path = ''
config_env = ''


class MainHandler(RequestHandler, ABC):
    def get(self):
        self.set_status(200)
        self.set_header("Content-Type", "text/html")
        with open(os.path.join(webapp_home_path, "dist", "index.html"), "r") as f:
            self.write(f.read())


class UpdateConfigHandler(RequestHandler, ABC):
    def patch(self):
        logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
        try:
            request_body = json.loads(self.request.body)
            if "DAB-ACCOUNT-ID" in request_body:
                dab_config.api_credentials['DAB-ACCOUNT-ID'] = request_body['DAB-ACCOUNT-ID']
            if "ACCESS-TOKEN" in request_body:
                dab_config.api_credentials[f'{config_env}-OAUTH']['access-token'] = request_body['ACCESS-TOKEN']
            if "REFRESH-TOKEN" in request_body:
                dab_config.api_credentials[f'{config_env}-OAUTH']['refresh-token'] = request_body['REFRESH-TOKEN']
            if "LOCAL-DEVICE-ID" in request_body:
                dab_config.api_credentials['LOCAL-DEVICE-ID'] = request_body['LOCAL-DEVICE-ID']
            dab_config.write_environment_configuration(new_environments=dab_config.api_credentials)

            if "CLIENT-ID" in request_body:
                sdk_config.update_sdk_configuration(client_id=request_body['CLIENT-ID'])
            self.set_status(200)
            self.write({})
        except Exception as exc:
            logging.error("Exception occurred in DevicesController. ", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))


def config_app(current_path="."):
    return Application([
        # Home
        (r"/", MainHandler),


        # Service Routes
        (r"/services", ServicesController),
        (r"/services/(?P<service_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12})",
         ServicesController),
        (r"/services/list", ServicesListController),
        (r"/services/(?P<service_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{"
         r"12})/activation", ServicesActivationController),
        (r"/services/samples/available", ServicesTemplateListAvailableController),

        # Transactions Routes
        (r"/transactions", TriggerTransactionsController),
        (r"/transactions/list", TransactionsController),
        (r"/transactions/(?P<transaction_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12})",
         TransactionsController),

        # Grants Routes
        (r"/devices/service-subscription", DeviceGrantsController),
        (r"/devices/(?P<device_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12})/grants/("
         r"?P<grant_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12})",
         DeviceGrantsController),

        # Device Routes
        (r"/devices", DevicesController),
        (r"/devices/(?P<device_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12})", DevicesController),
        (r"/devices/assignment/(?P<device_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12})", DeviceAssignmentController),
        (r"/devices/query", DevicesQueryController),
        (r"/devices/(?P<device_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12})/activation", DevicesActivationController),

        # Config Routes
        (r"/config", UpdateConfigHandler),

    ], static_path=os.path.join(os.path.dirname(__file__), "dist", "static"))


def setup_args():
    parser = argparse.ArgumentParser(description="DAB SDK - Device Registration Script",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument("-e", "--env", help="DAB environment", default='BT3-DEMO', nargs='?')
    parser.add_argument("-c", "--credentials", help="API Credentials file",  nargs='?')
    parser.add_argument("-p", "--port", help="Server Port", type=int, default=8888, nargs='?')
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable Debug logging")

    args = parser.parse_args()

    return vars(args)


if __name__ == "__main__":
    webapp_paths_adapter.dummy()
    config = setup_args()

    if config is None:

        logging.error('Configuration not found. WebApp cannot be executed.')
        exit(1)

    else:
        debugMode = config['verbose']
        if debugMode:
            logging.root.setLevel(logging.DEBUG)

        webapp_home_path = os.path.abspath(os.path.dirname(__file__))
        logging.debug('WebApp Runtime Path: %s', webapp_home_path)

        config_file_path = os.path.join(webapp_home_path, "api_credentials.json")
        if config['credentials'] is not None:
            config_file_path = config['credentials']

        config_env = config['env']
        dab_config.load_environment_configuration(config_env, config_file_path),
        sdk_config.load_sdk_configuration()
        dmn_config.load_dmn_files(f"{webapp_home_path}/scripts/")

        try:
            app = config_app(webapp_home_path)
            http_server = HTTPServer(app)
            define('port', default=config['port'], help='port to listen on')
            http_server.listen(config['port'])

            print('Listening on http://localhost:%i' % options.port)
            IOLoop.instance().start()

            logging.info("Exit...")

        except KeyboardInterrupt as e:
            logging.info("Shutdown received...")
        except Exception as e:
            logging.warning("Unexpected shutdown...", e)
            exit(1)
        finally:
            logging.info("Exit...")
    exit(0)
