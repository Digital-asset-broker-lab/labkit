#!/bin/bash
apt update -y 
apt install python3 python3-pip pipenv -y
pip install Tornado 
pip install regex 
pip install requests
