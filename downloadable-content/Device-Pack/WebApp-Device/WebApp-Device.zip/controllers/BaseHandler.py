from abc import ABC
from tornado.web import RequestHandler


class BaseHandler(RequestHandler, ABC):

    access_control_allow_origin = None;

    def enabling_cors(self) -> None:
        if self.access_control_allow_origin:
            self.set_header("Access-Control-Allow-Origin", self.access_control_allow_origin)
            self.set_header("Access-Control-Allow-Headers", "x-requested-with")
            self.set_header('Access-Control-Allow-Methods', 'POST, GET, DELETE, PATCH, PUT, OPTIONS')

    def options(self):
        pass
