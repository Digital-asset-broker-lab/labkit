from abc import ABC
import logging
import json
import tornado.web
from scripts.config import dab_config
from scripts import transaction_list, transaction_details, device_trigger_transaction
from scripts.utils.json_utils import error_json_formatter


class TransactionsController(tornado.web.RequestHandler, ABC):
    def post(self):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            request_body = json.loads(self.request.body)
            response_code, response_data = \
                transaction_list.get_transaction_list(request_body=request_body,
                                                      dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in TransactionsController, Query Transaction")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))

    def get(self, transaction_id):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            response_code, response_data = \
                transaction_details.get_transaction_details(transaction_id=transaction_id,
                                                            dab_account_id=dab_config.api_credentials['DAB-ACCOUNT-ID'])
            self.set_status(response_code)
            if response_code == 401:
                self.write(error_json_formatter(str("401 - Unauthorized. Please verify/update your access token.")))
            else:
                self.write(response_data)
        except Exception as exc:
            logging.error("Exception occurred in TransactionsController, List Transaction")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))


class TriggerTransactionsController(tornado.web.RequestHandler, ABC):
    def post(self):
        try:
            logging.debug('Request received \n URI %s\nBody %s', self.request.uri, self.request.body)
            request_body = json.loads(self.request.body)
            service_name = request_body.get('serviceName')
            triggers = request_body.get('triggers')
            response_code, response_data = \
                device_trigger_transaction.trigger_transaction(decision_key=service_name,
                                                               triggers=triggers)
            if response_code == 0:
                self.set_status(201)
                self.write({})
            else:
                raise EnvironmentError(f"DAB SDK returns an error ({response_code}) on Device Transactions."
                                       f" {response_data}")
        except Exception as exc:
            logging.error("Exception occurred in TriggerTransactionsController, Send Business Transaction")
            logging.debug("Error Details: %s", exc)
            self.set_status(500)
            self.write(error_json_formatter(str(exc)))
