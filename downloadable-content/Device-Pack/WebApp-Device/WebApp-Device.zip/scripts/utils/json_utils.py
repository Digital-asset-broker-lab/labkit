import regex


def extract_json_from_string(input_string):
    pattern = regex.compile(r'\{(?:[^{}]|(?R))*\}')
    return pattern.findall(input_string)


def error_json_formatter(error_details, error_code="LAB999", error_type="serverError",
                         error_message="Internal Labkit Error"):
    return  {
        "code": error_code,
        "type": error_type,
        "message": error_message,
        "details": error_details
    }
