import argparse
import logging
import scripts_paths_adapter
import json
from scripts.config import dab_config, dmn_config
from scripts.utils.request_utils import send_request, default_response_handling


def update(service_id, request_body, dab_account_id):

    logging.debug('Updating Service. Service ID: %s', service_id)
    logging.debug('Request Body: %s', request_body)
    extra_headers = {}
    if dab_account_id is not None and len(dab_account_id) > 0:
        extra_headers = {
            "x-jws-signature": dab_account_id
        }
    url = dab_config.services['prov'] + f"/services/{service_id}"

    resp = send_request(_method='PATCH', _url=url, _credentials=dab_config.api_credentials, _scope="BT3-DEMO-OAUTH",
                        _environment=dab_config.environments, _dab_account_id=dab_account_id,
                        _additional_headers=extra_headers, _json_data=request_body)

    return default_response_handling(resp)


def setup_args():
    json_example = {
        "name": "Parking Service",
        "expirationDate": "2031-12-10T11:04:33.842",
        "acceptedPaymentMethods": [
          {
            "paymentMethod": "VISA_TOKEN"
          }
        ],
        "description": "string"
    }

    parser = argparse.ArgumentParser(description="DAB Services - Service Update Script",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter, exit_on_error=False)
    parser.add_argument('-e', '--env', help='DAB environment', default='BT3-DEMO', nargs='?')
    parser.add_argument("-c", "--credentials", help="API Credentials file", default='api_credentials.json', nargs='?')
    parser.add_argument('-v', '--verbose', action='store_true', help='Enable Debug logging')
    parser.add_argument("-s", "--service", help="Service ID", nargs='?')
    service_template_list = []
    for service_template in dmn_config.services_available:
        service_template_list.append(service_template['service_name'])
    parser.add_argument('-j', '--json', help=f'Json. E.g.: {json_example}', default='{}',  nargs='?')
    parser.add_argument('-a', '--account', help='DAB Account ID', nargs='?')
    args = parser.parse_args()
    return vars(args)


if __name__ == '__main__':
    scripts_paths_adapter.dummy()
    dmn_config.load_dmn_files()
    config = setup_args()

    if config is None:

        logging.error('Configuration not found. Script cannot be executed.')
        exit(1)

    else:

        dab_config.load_environment_configuration(config['env'], config['credentials']),
        debugMode = config['verbose']
        if debugMode:
            logging.root.setLevel(logging.DEBUG)

        try:

            service = config['service']
            dab_account = None
            if config['account'] is not None:
                dab_account = config['account']
            else:
                dab_account = dab_config.api_credentials['DAB-ACCOUNT-ID']

            json = json.loads(config['json'])

            response_code, response_data = update(service_id=service, request_body=json, dab_account_id=dab_account)

            if response_code >= 400:
                logging.error('Service Update returns an error code: %s. Response content: %s',
                              response_code, response_data)
                print(response_data)
                exit(response_code)
            else:
                print(response_data)

        except Exception as e:
            logging.error('Service Update could not be processed', e)
            exit(1)

    exit(0)
