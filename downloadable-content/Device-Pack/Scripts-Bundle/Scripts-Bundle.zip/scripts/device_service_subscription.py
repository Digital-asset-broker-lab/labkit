import argparse
import logging
import scripts_paths_adapter
from scripts.config import dab_config
from scripts.utils.request_utils import send_request, has_json, default_response_handling


def service_subscription(request_body, dab_account_id):

    logging.debug('Device Service Subscription. Request Body: %s', request_body)
    extra_headers = {}
    if dab_account_id is not None and len(dab_account_id) > 0:
        extra_headers = {
            "x-jws-signature": dab_account_id
        }
    url = dab_config.services['auth'] + f"/devices/service-subscription"

    resp = send_request(_method='POST', _url=url, _credentials=dab_config.api_credentials, _scope="BT3-DEMO-OAUTH",
                        _environment=dab_config.environments, _dab_account_id=dab_account_id,
                        _additional_headers=extra_headers, _json_data=request_body)

    return default_response_handling(resp)


def setup_args():
    parser = argparse.ArgumentParser(description="DAB Services - Device Service Subscription Script",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter, exit_on_error=False)
    parser.add_argument('-e', '--env', help='DAB environment', default='BT3-DEMO', nargs='?')
    parser.add_argument("-c", "--credentials", help="API Credentials file", default='api_credentials.json', nargs='?')
    parser.add_argument('-v', '--verbose', action='store_true', help='Enable Debug logging')
    parser.add_argument("-d", "--device", help="Device ID", nargs='?', required=True)
    parser.add_argument("-s", "--service", help="Service ID", nargs='?', required=True)
    parser.add_argument("-p", "--payment_method", help="Selected Payment Method", nargs='?', required=True,
                        choices=['VISA_TOKEN', 'VDF_TOKEN', 'MCP'])
    parser.add_argument('-a', '--account', help='DAB Account ID', nargs='?')
    args = parser.parse_args()
    return vars(args)


if __name__ == '__main__':
    scripts_paths_adapter.dummy()
    config = setup_args()

    if config is None:

        logging.error('Configuration not found. Script cannot be executed.')
        exit(1)

    else:

        dab_config.load_environment_configuration(config['env'], config['credentials']),
        debugMode = config['verbose']
        if debugMode:
            logging.root.setLevel(logging.DEBUG)

        try:

            service = config['service']
            device = config['device']
            payment_method = config['payment_method']

            dab_account = None
            if config['account'] is not None:
                dab_account = config['account']
            else:
                dab_account = dab_config.api_credentials['DAB-ACCOUNT-ID']

            req_json = {
              "serviceId": service,
              "deviceId": device,
              "paymentMethod": payment_method
            }

            response_code, response_data = service_subscription(request_body=req_json, dab_account_id=dab_account)

            if response_code >= 400:
                logging.error('Device Service Subscription returns an error code: %s. Response content: %s',
                              response_code, response_data)
                print(response_data)
                exit(response_code)
            else:
                print(response_data)

        except Exception as e:
            logging.error('Device Service Subscription could not be processed', e)
            exit(1)

    exit(0)
