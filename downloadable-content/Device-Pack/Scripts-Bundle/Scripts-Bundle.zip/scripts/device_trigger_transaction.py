import argparse
import logging
import subprocess
import shlex
import scripts_paths_adapter
from scripts.config import dab_config, sdk_config
from scripts.utils import json_utils


def trigger_transaction(decision_key, triggers):

    dab_app_wrapper = sdk_config.sdk['DAB_APP_WRAPPER_PATH']
    config_ini = sdk_config.sdk['CONFIG_INI_PATH']
    decision_key = decision_key.replace(" ", "_")
    try:
        command_string = f'{dab_app_wrapper} -c "{config_ini}" -a "{decision_key}"'
        for trigger in triggers:
            command_string += f' -t "{trigger[0]}" "{trigger[1]}" "{trigger[2]}" '

        logging.debug("SDK Command Generated: %s", command_string)
        completed_process = subprocess.run(shlex.split(command_string), timeout=90,
                                           capture_output=True, text=True, )

        return_data = completed_process.stdout

        if completed_process.returncode != 0:
            logging.warning('Process failed because did not return a successful return code: %s',
                            completed_process.returncode)
            return_data = completed_process.stderr

        return completed_process.returncode, return_data

    except FileNotFoundError as exc:
        logging.fatal('Process failed because the executable could not be found.\n %s')
        raise exc

    except subprocess.SubprocessError as exc:
        logging.warning('Error on execute subprocess call: %s', exc)
        raise exc


def setup_args():

    parser = argparse.ArgumentParser(description="DAB SDK - Device Registration Script",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument("-e", "--env", help="DAB environment", default='BT3-DEMO', nargs='?')
    parser.add_argument("-c", "--credentials", help="API Credentials file", default='api_credentials.json', nargs='?')
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable Debug logging")
    parser.add_argument("-k", "--service-name", "--decision-key", help="Service Name or Decision key name",
                        required=True)
    parser.add_argument("-t", "--trigger", action='append', nargs=3, metavar=('NAME', 'TYPE', 'VALUE'), required=True,
                        help="(REPEATABLE) Parameter sent to be processed by selected Service on DAB.\n"
                             "Each trigger (-t) contains 3 values, "
                             "and multiple trigres could be sent on same command\n\n"
                             "E.g.:\n -t NAME_1 TYPE_1 VALUE_1 -t NAME_2 TYPE_2 VALUE_2 -t NAME_N TYPE_N VALUE_N")
    args = parser.parse_args()

    return vars(args)


if __name__ == '__main__':
    scripts_paths_adapter.dummy()
    config = setup_args()

    if config is None:

        logging.error('Configuration not found. Script cannot be executed.')
        exit(1)

    else:

        dab_config.load_environment_configuration(config['env'], config['credentials']),
        sdk_config.load_sdk_configuration()
        debugMode = config['verbose']

        if debugMode:
            logging.root.setLevel(logging.DEBUG)

        try:

            service_name = config['service_name']
            triggers_list = config['trigger']
            response_code, response_data = trigger_transaction(decision_key=service_name, triggers=triggers_list)
            if response_code != 0:
                logging.warning("DAB SDK returned an error when Triggering Transaction on a device: %s", response_data)

            json_content = json_utils.extract_json_from_string(response_data)
            if json_content:
                for json in json_content:
                    print(json)
            else:
                print(response_data)
            exit(response_code)

        except Exception as e:
            logging.error('Device Triggering Transaction Script could not be processed', e)
            exit(1)
