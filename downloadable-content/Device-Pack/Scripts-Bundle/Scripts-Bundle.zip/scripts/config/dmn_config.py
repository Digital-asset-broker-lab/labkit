import logging

xml_files = [
    {
        'service_name': 'beverages',
        'file': 'dmn_samples/camundasimulation.xml'
    },
    {
        'service_name': 'MyIDService',
        'file': 'dmn_samples/deviceidservice.xml'
    },
    {
        'service_name': 'EX3_CustomService',
        'file': 'dmn_samples/ex3.xml'
    },
    {
        'service_name': 'TemperatureComparator',
        'file': 'dmn_samples/ex3a.xml'
    },
    {
        'service_name': 'HelloService',
        'file': 'dmn_samples/helloservice.xml'
    },
    {
        'service_name': 'Test',
        'file': 'dmn_samples/ms.xml'
    },
    {
        'service_name': 'TestParkingService',
        'file': 'dmn_samples/parkingservice.xml'
    },
    {
        'service_name': 'ThemePark',
        'file': 'dmn_samples/themeparkservice.xml'
    },
]

services_available = []


def load_dmn_files(base_path=''):
    for xml_file in xml_files:
        dmn_code = None
        try:
            logging.debug('Expecting DMN code in %s', xml_file['file'])
            with open(base_path+xml_file['file']) as fp:
                dmn_code = fp.read()
        except IOError as exc:
            logging.debug("File not found %s ", xml_file['file'], exc)
            logging.error("File not found %s ", xml_file['file'])

        services_available.append({
            'service_name': xml_file['service_name'],
            'service_xml': dmn_code
        })
